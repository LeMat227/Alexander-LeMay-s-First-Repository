function setup() {
  createCanvas(500, 400);
}

function draw() {
  background(220);
  noStroke();
  rectMode(CORNER);
  fill(200);
  fill( "hsl(180,85%,43%)" ) 
  rect(0, 0, 500, 270);
  
noStroke();
  rectMode(CORNER);
  fill(200);
  fill( "hsl(61,78%,75%)" ) 
  rect(0, 270, 500, 250);
  
  stroke("black")
  strokeWeight(1);
  fill(200);
  fill( "hsl(101,81%,24%)"); 
   ellipse(90, 150, 80, 50);
   triangle(120,150, 140, 110, 150, 180);
   triangle(90,160, 100, 170, 100, 190);
   fill(200);
  fill( "white)" ) 
  ellipse(70, 145, 20, 20);
  fill(200);
  fill( "black" ) 
  ellipse(70, 145, 10, 10);
  arc(52, 160, 40, 35, 0 ,1);
  noFill();

  
   fill(200);
  fill( "#AC18C5" ) 
  ellipse(350, 200, 50, 85);
  triangle(350,170, 400, 140, 300, 140);
  triangle(340,200, 400, 170, 370, 200);
     fill(200);
  fill( "white)" ) 
  ellipse(350, 230, 20, 20);
  fill(200);
  fill( "black" ) 
  ellipse(350, 230, 10, 10);


}